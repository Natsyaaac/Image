import cv2 as cv
import numpy as np

img = cv.imread('gambar/rame3.jpg')
cv.imshow('Warna Gambar Asli', img)

# Blur pada gambar
blur = cv.GaussianBlur(img, (9, 9), cv.BORDER_DEFAULT)
cv.imshow('Gambar Blur', blur)

cv.waitKey(0)
cv.destroyAllWindows()