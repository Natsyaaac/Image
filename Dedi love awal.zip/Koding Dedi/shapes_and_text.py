
import cv2
import numpy as np

def create_blank_image(width=512, height=512, color=(255, 255, 255)):
    image = np.ones((height, width, 3), dtype=np.uint8) * np.array(color, dtype=np.uint8)
    return image

def draw_shapes(image):
    cv2.line(image, (50, 50), (200, 50), (0, 0, 255), thickness=2)
    cv2.rectangle(image, (50, 100), (200, 200), (255, 0, 0), thickness=2)
    cv2.circle(image, (300, 150), 50, (0, 255, 0), thickness=-1)
    cv2.ellipse(image, (400, 150), (50, 30), 0, 0, 360, (128, 0, 128), thickness=2)
    points = np.array([[450, 50], [500, 100], [475, 150], [425, 150]], np.int32)
    points = points.reshape((-1, 1, 2))
    cv2.polylines(image, [points], isClosed=True, color=(0, 165, 255), thickness=2)

def place_text(image):
    cv2.putText(image, "Hallo, FIKOM UM METRO", (50, 300), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), thickness=2)
    cv2.putText(image, "Belajar Python", (50, 350), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 0, 0), thickness=2)

def main():
    image = create_blank_image()
    draw_shapes(image)
    place_text(image)
    cv2.imshow("Gambar dengan Bentuk & Teks", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    cv2.imwrite("gambar_dengan_bentuk_dan_teks.jpg", image)
    print("Gambar telah disimpan sebagai 'gambar_dengan_bentuk_dan_teks.jpg'.")

main()
