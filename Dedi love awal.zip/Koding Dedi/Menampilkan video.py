import cv2 as cv

# Buka file video
capture = cv.VideoCapture('motor.mp4')

# Cek apakah video berhasil dibuka
if not capture.isOpened():
    print("Gagal membuka video. Pastikan file 'motor.mp4' ada di folder yang sama dengan script ini.")
    exit()

# Baca dan tampilkan video frame per frame
while True:
    isTrue, frame = capture.read()

    if not isTrue:
        print("Video selesai atau gagal membaca frame.")
        break

    cv.imshow('Video', frame)

    # Tekan tombol 'd' untuk keluar
    if cv.waitKey(20) & 0xFF == ord('d'):
        break

# Bersihkan semuanya
capture.release()
cv.destroyAllWindows()
