import cv2 as cv
import numpy as np

img = cv.imread('gambar/rame3.jpg')
cv.imshow('Warna Gambar Asli', img)

# Garis tepi gambar
canny = cv.Canny(img, 125, 175)
cv.imshow('Garis Tepi Gambar', canny)

cv.waitKey(0)
cv.destroyAllWindows()