import cv2 as cv
import numpy as np

img = cv.imread('gambar/ramel.jpg')
cv.imshow('Ramel', img)

# Membuat gambar kosong
blank = np.zeros(img.shape[:2], dtype='uint8')

# Split warna
b, g, r = cv.split(img)

# Tampilkan tiap warna
blue = cv.merge([b, blank, blank])
green = cv.merge([blank, g, blank])
red = cv.merge([blank, blank, r])

cv.imshow('Blue', blue)
cv.imshow('Green', green)
cv.imshow('Red', red)

print("Original shape:", img.shape)
print("Blue shape:", b.shape)
print("Green shape:", g.shape)
print("Red shape:", r.shape)

# Gabungkan kembali
merged = cv.merge([b, g, r])
cv.imshow('Merged Image', merged)

cv.waitKey(0)
cv.destroyAllWindows()