import cv2

# Baca gambar
img = cv2.imread('bromo.jpg')

# Membuat jendela yang bisa di-resize
cv2.namedWindow('gr21', cv2.WINDOW_NORMAL)

# Tampilkan gambar
cv2.imshow('gr21', img)

# Simpan gambar (ukuran aslinya, tidak diresize)
cv2.imwrite('save_bromo.jpg', img)

# Tunggu tombol ditekan lalu tutup
cv2.waitKey(0)
cv2.destroyAllWindows()
