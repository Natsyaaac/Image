import cv2 as cv
import numpy as np

img = cv.imread('gambar/rame3.jpg')
cv.imshow('Warna Gambar Asli', img)

# Konversi ke hitam putih
gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
cv.imshow('Warna Konversi Hitam Putih', gray)

cv.waitKey(0)
cv.destroyAllWindows()