
import cv2

def rescaleFrame(frame, scale=0.3):
    width = int(frame.shape[1] * scale)
    height = int(frame.shape[0] * scale)
    dimensions = (width, height)
    return cv2.resize(frame, dimensions, interpolation=cv2.INTER_AREA)

img = cv2.imread('gambar/IMG-20250314-WA0075.jpg')

if img is not None:
    resized_img = rescaleFrame(img)
    cv2.imshow('Original Image', img)
    cv2.imshow('Resized Image', resized_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
else:
    print("Gambar tidak ditemukan.")
